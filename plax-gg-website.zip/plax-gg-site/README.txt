PLAX.GG WEBSITE

This is a static website package for the PLAX Crosshair Windows app.

FILES
- index.html: the website
- downloads/Plax-Crosshair-Windows-v8.zip: the real app download

PREVIEW
Open index.html in a browser.

PUBLISH
Upload the contents of this folder to your static website host (for example, Netlify, Cloudflare Pages, or your web host). Keep the downloads folder beside index.html so the download button works.

DOMAIN
To use plax.gg, purchase/configure the domain with your registrar and point its DNS records to the hosting provider. The domain is not registered or published by this package.
