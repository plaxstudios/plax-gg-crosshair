PLAX CROSSHAIR

1. Extract the entire CrosshairStudio folder.
2. Keep Plax.ico, Launch-CrosshairStudio.ps1, and Start-Crosshair-Studio.bat together.
3. Double-click Start-Crosshair-Studio.bat to launch.

The app uses Windows PowerShell and built-in Windows Forms; Python is not required.
The Plax P icon is loaded from this folder and is used for the app window/taskbar icon.
