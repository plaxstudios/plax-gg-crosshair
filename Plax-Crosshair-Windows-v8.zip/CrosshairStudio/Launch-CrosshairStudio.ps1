# Crosshair Studio - one-window Windows overlay. Uses built-in PowerShell + .NET WinForms.
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$src = @'
using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Collections.Generic;

public class CrosshairOverlay : Form {
 [DllImport("user32.dll")] static extern int GetWindowLong(IntPtr hWnd,int nIndex);
 [DllImport("user32.dll")] static extern int SetWindowLong(IntPtr hWnd,int nIndex,int dwNewLong);
 const int GWL_EXSTYLE=-20, WS_EX_TRANSPARENT=0x20, WS_EX_TOOLWINDOW=0x80, WS_EX_LAYERED=0x80000;
 public string Shape="Classic"; public Color Ink=Color.White; public int SizePx=24, Thick=3, Gap=5; public bool Outline=true; public int Alpha=255;
 public CrosshairOverlay(){FormBorderStyle=FormBorderStyle.None;ShowInTaskbar=false;TopMost=true;StartPosition=FormStartPosition.Manual;BackColor=Color.Magenta;TransparencyKey=Color.Magenta;Width=240;Height=240;}
 protected override CreateParams CreateParams {get{var cp=base.CreateParams;cp.ExStyle|=WS_EX_TRANSPARENT|WS_EX_TOOLWINDOW|WS_EX_LAYERED;return cp;}}
 protected override void OnShown(EventArgs e){base.OnShown(e);SetWindowLong(Handle,GWL_EXSTYLE,GetWindowLong(Handle,GWL_EXSTYLE)|WS_EX_TRANSPARENT|WS_EX_TOOLWINDOW|WS_EX_LAYERED);}
 public void Reposition(){Rectangle b=Screen.PrimaryScreen.Bounds;Bounds=new Rectangle(b.Left+(b.Width-Width)/2,b.Top+(b.Height-Height)/2,Width,Height);Invalidate();}
 protected override void OnPaint(PaintEventArgs e){base.OnPaint(e);StudioForm.DrawCrosshair(e.Graphics,Width/2f,Height/2f,Shape,SizePx,Thick,Gap,Ink,Alpha,Outline,false);}
}
public class StudioForm : Form {
 CrosshairOverlay overlay=new CrosshairOverlay(); Panel preview=new Panel(); FlowLayoutPanel gallery=new FlowLayoutPanel(); TrackBar size=new TrackBar(), thick=new TrackBar(), gap=new TrackBar(), opacity=new TrackBar(); Button color=new Button(), toggle=new Button(), save=new Button(), load=new Button(); CheckBox outline=new CheckBox(); Label status=new Label(); Color ink=Color.White; string selected="Classic"; bool active=true; List<Panel> tiles=new List<Panel>();
 string[] names={"Classic","Tiny Plus","Open Plus","Dot","Big Dot","Circle","Ring Dot","X Cross","Thin X","T Shape","Bottom T","Four Corners","Bracket","Square","Small Square","Diamond","Arrow Up","Minimal","Heavy Plus","Precision","Wide Plus","Micro Dot","Hollow Dot","Double Ring","Long X","Short X","Top Bracket","Side Brackets","Bottom Bracket","Eight Dot","Four Dot","Cross Dot","Open Diamond","Wide Diamond","Chevron","V Shape","Target","Tiny Circle","Plus Dot","Split X","Long T","Offset Plus","Mini Bracket","Bold Square","Hollow Square","Triple Dot","Center Gap","Sharp Cross","Scope"};
 string[] shapes={"Classic","Classic","Cross","Dot","Dot","Circle","Circle","X","X","T","T","Corners","Corners","Square","Square","Diamond","Arrow","Classic","Classic","Cross","Classic","Dot","Dot","Circle","X","X","Corners","Corners","Corners","Dot","Dot","Cross","Diamond","Diamond","Arrow","T","Circle","Circle","Classic","X","T","Classic","Corners","Square","Square","Dot","Cross","Classic","Circle"};
 public StudioForm(){
  Text="Plax Crosshair";try{Icon=new Icon(System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"Plax.ico"));}catch{};Size=new Size(1120,790);MinimumSize=new Size(1050,740);StartPosition=FormStartPosition.CenterScreen;BackColor=Color.FromArgb(8,8,10);ForeColor=Color.White;Font=new Font("Segoe UI",9);FormBorderStyle=FormBorderStyle.FixedSingle;MaximizeBox=false;
  Label head=new Label(){Text="PLAX CROSSHAIR",Font=new Font("Segoe UI",19,FontStyle.Bold),ForeColor=Color.White,Location=new Point(24,18),AutoSize=true};Controls.Add(head);
  Label sub=new Label(){Text="Choose a preset, preview it, then fine-tune every detail",ForeColor=Color.FromArgb(151,164,185),Location=new Point(27,54),AutoSize=true};Controls.Add(sub);
  Label gl=new Label(){Text="CROSSHAIR PRESETS",Font=new Font("Segoe UI",10,FontStyle.Bold),ForeColor=Color.FromArgb(190,202,220),Location=new Point(26,94),AutoSize=true};Controls.Add(gl);
  Label logo=new Label(){Text="P",Font=new Font("Arial",22,FontStyle.Bold),ForeColor=Color.White,BackColor=Color.FromArgb(20,24,32),TextAlign=ContentAlignment.MiddleCenter,BorderStyle=BorderStyle.FixedSingle,Location=new Point(26,692),Size=new Size(42,42)};logo.Paint+=(s,e)=>{using(Pen p=new Pen(Color.FromArgb(70,190,255),2))e.Graphics.DrawRectangle(p,0,0,logo.Width-1,logo.Height-1);};Controls.Add(logo);
  gallery.Location=new Point(24,124);gallery.Size=new Size(650,560);gallery.BackColor=Color.FromArgb(8,8,10);gallery.AutoScroll=true;gallery.WrapContents=true;gallery.FlowDirection=FlowDirection.LeftToRight;Controls.Add(gallery);
  for(int i=0;i<names.Length;i++) AddTile(i);
  Panel right=new Panel(){Location=new Point(700,92),Size=new Size(390,622),BackColor=Color.FromArgb(17,17,20),AutoScroll=true};right.VerticalScroll.Enabled=true;right.VerticalScroll.Visible=true;right.AutoScrollMinSize=new Size(0,690);Controls.Add(right);
  Label pl=new Label(){Text="LIVE PREVIEW",Font=new Font("Segoe UI",10,FontStyle.Bold),ForeColor=Color.FromArgb(190,202,220),Location=new Point(18,16),AutoSize=true};right.Controls.Add(pl);
  preview=new Panel(){Location=new Point(18,45),Size=new Size(354,170),BackColor=Color.FromArgb(5,5,7)};preview.Paint+=(s,e)=>DrawCrosshair(e.Graphics,preview.Width/2f,preview.Height/2f,selected,size.Value,thick.Value,gap.Value,ink,opacity.Value,outline.Checked);right.Controls.Add(preview);
  AddLabel(right,"SIZE",18,232);AddTrack(right,size,18,250,350,4,90,26);
  AddLabel(right,"THICKNESS",18,322);AddTrack(right,thick,18,340,350,1,14,3);
  AddLabel(right,"CENTRE GAP",18,412);AddTrack(right,gap,18,430,350,0,36,6);
  AddLabel(right,"OPACITY",18,502);AddTrack(right,opacity,18,520,350,20,255,255);
  outline.Text="Black outline";outline.Location=new Point(18,580);outline.Checked=true;outline.AutoSize=true;outline.CheckedChanged+=(s,e)=>UpdateAll();right.Controls.Add(outline);
  color.Text="Choose colour";color.Location=new Point(18,606);color.Size=new Size(120,34);StyleButton(color);color.Click+=(s,e)=>{using(ColorDialog d=new ColorDialog()){d.Color=ink;if(d.ShowDialog(this)==DialogResult.OK){ink=d.Color;UpdateAll();}}};right.Controls.Add(color);
  toggle.Text="Hide overlay";toggle.Location=new Point(150,606);toggle.Size=new Size(105,34);StyleButton(toggle);toggle.Click+=(s,e)=>{active=!active;if(active){overlay.Show();overlay.Reposition();}else overlay.Hide();toggle.Text=active?"Hide overlay":"Show overlay";};right.Controls.Add(toggle);
  save.Text="Save";save.Location=new Point(266,606);save.Size=new Size(48,34);StyleButton(save);save.Click+=(s,e)=>SaveSettings();right.Controls.Add(save);
  load.Text="Load";load.Location=new Point(320,606);load.Size=new Size(52,34);StyleButton(load);load.Click+=(s,e)=>LoadSettings();right.Controls.Add(load);
  status.Text="";
  overlay.Show();overlay.Reposition();UpdateAll();FormClosing+=(s,e)=>overlay.Close();
 }
 void AddTile(int i){Panel p=new Panel(){Width=148,Height=112,Margin=new Padding(0,0,10,10),BackColor=Color.FromArgb(20,20,23),Tag=i};p.Paint+=(s,e)=>{int ix=(int)p.Tag;using(Pen border=new Pen(ix==Array.IndexOf(names,selected)?Color.FromArgb(65,190,255):Color.FromArgb(53,64,82),ix==Array.IndexOf(names,selected)?2:1))e.Graphics.DrawRectangle(border,0,0,p.Width-1,p.Height-1);DrawCrosshair(e.Graphics,p.Width/2f,40,shapes[ix],22,3,5,Color.White,255,true);using(SolidBrush b=new SolidBrush(Color.FromArgb(220,230,242)))e.Graphics.DrawString(names[ix],new Font("Segoe UI",8,FontStyle.Bold),b,8,79);};p.Click+=(s,e)=>{selected=names[i];UpdateAll();};foreach(Control c in p.Controls)c.Click+=(s,e)=>{selected=names[i];UpdateAll();};gallery.Controls.Add(p);tiles.Add(p);}
 void AddLabel(Control parent,string t,int x,int y){parent.Controls.Add(new Label(){Text=t,Location=new Point(x,y),AutoSize=true,ForeColor=Color.FromArgb(170,183,204),Font=new Font("Segoe UI",8,FontStyle.Bold)});}
 void AddTrack(Control parent,TrackBar b,int x,int y,int w,int min,int max,int val){b.Location=new Point(x,y);b.Width=w;b.Minimum=min;b.Maximum=max;b.Value=val;b.TickFrequency=Math.Max(1,(max-min)/9);b.ValueChanged+=(s,e)=>UpdateAll();parent.Controls.Add(b);}
 void StyleButton(Button b){b.FlatStyle=FlatStyle.Flat;b.FlatAppearance.BorderColor=Color.FromArgb(65,78,99);b.BackColor=Color.FromArgb(36,44,58);b.ForeColor=Color.White;}
 void UpdateAll(){if(overlay==null)return;int ix=Array.IndexOf(names,selected);overlay.Shape=shapes[ix<0?0:ix];overlay.SizePx=size.Value;overlay.Thick=thick.Value;overlay.Gap=gap.Value;overlay.Ink=ink;overlay.Alpha=opacity.Value;overlay.Outline=outline.Checked;overlay.Invalidate();if(preview!=null)preview.Invalidate();foreach(Panel p in tiles)p.Invalidate();status.Text="Selected: "+selected+"  •  "+size.Value+" px size  •  Overlay "+(active?"on":"off");}
 public static void DrawCrosshair(Graphics g,float cx,float cy,string shape,int size,int thick,int gap,Color ink,int alpha,bool outline,bool smooth=true){g.SmoothingMode=smooth?SmoothingMode.AntiAlias:SmoothingMode.None;float s=size,t=thick,z=gap;Color c=Color.FromArgb(alpha,ink);using(Pen p=new Pen(c,t)){p.StartCap=p.EndCap=LineCap.Round;using(Pen o=new Pen(Color.FromArgb(alpha,Color.Black),t+2)){o.StartCap=o.EndCap=LineCap.Round;Action<float,float,float,float> L=(a,b,d,f)=>{if(outline)g.DrawLine(o,a,b,d,f);g.DrawLine(p,a,b,d,f);};if(shape=="Dot"){float d=Math.Max(3,t+1);if(outline)g.FillEllipse(Brushes.Black,cx-d/2-1,cy-d/2-1,d+2,d+2);using(SolidBrush br=new SolidBrush(c))g.FillEllipse(br,cx-d/2,cy-d/2,d,d);}else if(shape=="Circle"){if(outline)g.DrawEllipse(o,cx-s/2,cy-s/2,s,s);g.DrawEllipse(p,cx-s/2,cy-s/2,s,s);}else if(shape=="X"){L(cx-s/2,cy-s/2,cx-z/2,cy-z/2);L(cx+s/2,cy+s/2,cx+z/2,cy+z/2);L(cx+s/2,cy-s/2,cx+z/2,cy-z/2);L(cx-s/2,cy+s/2,cx-z/2,cy+z/2);}else if(shape=="T"){L(cx-s/2,cy-z,cx+s/2,cy-z);L(cx,cy-z,cx,cy+s/2);}else if(shape=="Corners"){float d=s/2;L(cx-d,cy-d,cx-d/2,cy-d);L(cx+d/2,cy-d,cx+d,cy-d);L(cx-d,cy+d,cx-d/2,cy+d);L(cx+d/2,cy+d,cx+d,cy+d);L(cx-d,cy-d,cx-d,cy-d/2);L(cx-d,cy+d/2,cx-d,cy+d);L(cx+d,cy-d,cx+d,cy-d/2);L(cx+d,cy+d/2,cx+d,cy+d);}else if(shape=="Square"){g.DrawRectangle(p,cx-s/2,cy-s/2,s,s);}else if(shape=="Diamond"){L(cx,cy-s/2,cx+s/2,cy);L(cx+s/2,cy,cx,cy+s/2);L(cx,cy+s/2,cx-s/2,cy);L(cx-s/2,cy,cx,cy-s/2);}else if(shape=="Arrow"){L(cx,cy-s/2,cx-s/2,cy);L(cx,cy-s/2,cx+s/2,cy);L(cx,cy-s/2,cx,cy+s/2);}else{L(cx-s/2,cy,cx-z/2,cy);L(cx+z/2,cy,cx+s/2,cy);L(cx,cy-s/2,cx,cy-z/2);L(cx,cy+z/2,cx,cy+s/2);}}}}
 string SettingsPath=Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData)+"\\PlaxCrosshair.json";
 void SaveSettings(){try{string j="{\"preset\":\""+selected+"\",\"size\":"+size.Value+",\"thick\":"+thick.Value+",\"gap\":"+gap.Value+",\"opacity\":"+opacity.Value+",\"color\":\""+ink.ToArgb()+"\",\"outline\":"+outline.Checked.ToString().ToLower()+"}";System.IO.File.WriteAllText(SettingsPath,j);status.Text="Settings saved";}catch(Exception ex){MessageBox.Show(this,ex.Message);}}
 void LoadSettings(){try{if(!System.IO.File.Exists(SettingsPath)){status.Text="No saved settings yet";return;}string j=System.IO.File.ReadAllText(SettingsPath);Func<string,string> get=k=>{int i=j.IndexOf("\""+k+"\":");if(i<0)return "";i+=k.Length+3;if(j[i]=='\"'){int z=j.IndexOf('\"',i+1);return j.Substring(i+1,z-i-1);}int e=j.IndexOfAny(new char[]{',','}'},i);return j.Substring(i,e-i);};string pr=get("preset");if(Array.IndexOf(names,pr)>=0)selected=pr;size.Value=Math.Max(size.Minimum,Math.Min(size.Maximum,int.Parse(get("size"))));thick.Value=Math.Max(thick.Minimum,Math.Min(thick.Maximum,int.Parse(get("thick"))));gap.Value=Math.Max(gap.Minimum,Math.Min(gap.Maximum,int.Parse(get("gap"))));opacity.Value=Math.Max(opacity.Minimum,Math.Min(opacity.Maximum,int.Parse(get("opacity"))));ink=Color.FromArgb(int.Parse(get("color")));outline.Checked=get("outline")=="true";UpdateAll();status.Text="Settings loaded";}catch(Exception ex){MessageBox.Show(this,"Couldn't load settings: "+ex.Message);}}
}
'@
Add-Type -TypeDefinition $src -ReferencedAssemblies System.Windows.Forms,System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()
# Short branded loading screen; it closes before the single main menu appears.
$splash = New-Object System.Windows.Forms.Form
$splash.Text = 'Plax Crosshair'
$splash.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::None
$splash.StartPosition = 'CenterScreen'
$splash.Size = New-Object System.Drawing.Size(500,270)
$splash.BackColor = [System.Drawing.Color]::FromArgb(7,7,9)
$splash.TopMost = $true
$brand = New-Object System.Windows.Forms.Label
$brand.Text = 'PLAX CROSSHAIR'
$brand.Font = New-Object System.Drawing.Font('Segoe UI',25,[System.Drawing.FontStyle]::Bold)
$brand.ForeColor = [System.Drawing.Color]::White
$brand.AutoSize = $true
$brand.Location = New-Object System.Drawing.Point(92,65)
$splash.Controls.Add($brand)
$tag = New-Object System.Windows.Forms.Label
$tag.Text = 'THE BEST CROSSHAIRS'
$tag.Font = New-Object System.Drawing.Font('Segoe UI',12,[System.Drawing.FontStyle]::Bold)
$tag.ForeColor = [System.Drawing.Color]::FromArgb(145,145,155)
$tag.AutoSize = $true
$tag.Location = New-Object System.Drawing.Point(158,119)
$splash.Controls.Add($tag)
$bar = New-Object System.Windows.Forms.ProgressBar
$bar.Location = New-Object System.Drawing.Point(75,180)
$bar.Size = New-Object System.Drawing.Size(350,7)
$bar.Style = 'Continuous'
$splash.Controls.Add($bar)
$loadTimer = New-Object System.Windows.Forms.Timer
$loadTimer.Interval = 100
$loadTimer.Add_Tick({ $bar.Value = [Math]::Min(100,$bar.Value+1); if ($bar.Value -ge 100) { $loadTimer.Stop(); $splash.Close() } })
$loadTimer.Start()
[System.Windows.Forms.Application]::Run($splash)
$loadTimer.Dispose()
$mainForm = [StudioForm]::new()
# Load the real P logo from the app folder (not PowerShell's System32 folder).
$mainForm.Icon = New-Object System.Drawing.Icon((Join-Path $PSScriptRoot 'Plax.ico'))
[System.Windows.Forms.Application]::Run($mainForm)
